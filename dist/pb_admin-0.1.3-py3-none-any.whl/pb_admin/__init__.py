"""Main module pb_admin project."""

__version__ = '0.1.3'
__author__ = 'Vaclav_V'
__all__ = ['tags']

from pb_admin import tags
